$( document ).ready(function(){
    //POPULA IMPRESSÃO
    var url_atual = window.location.origin;
    let url = window.location.pathname;
    let parts = url.split('/');
    let id = parts.pop() || parts.pop();
    
    $.ajax({
        type: "GET",
        url: url_atual +'/api/popcomunicado/'+id,
        dataType: 'json',
        
    }).done(function(data) {
        console.log(data);
        $('#numeroComunicado').html(data[0].numeroComunicado);
        $('#nomePrestador').html(data[0].nomePrestador);
        $('#cnpj').html(data[0].cnpj);
        $('#numCredenciamento').html(data[0].numCredenciamento); 
        $('#localTratamento').html(data[0].localTratamento);
        $('#destino').html(data[0].destino);
        if(data[0].tratadoDestruido == 'T'){
            $('#tratado').html('<i class="fa fa-check-square-o" aria-hidden="true"></i>');
            $('#destruido').html('<i class="fa fa-minus-square-o" aria-hidden="true"></i>');
        }else{
            $('#tratado').html('<i class="fa fa-minus-square-o" aria-hidden="true"></i>');
            $('#destruido').html('<i class="fa fa-check-square-o" aria-hidden="true"></i>');
        }
        $('#numDescVolumes').html(data[0].numDescVolumes);
        $('#quantidade').html(data[0].quantidade);
        $('#marcas').html(data[0].marcas);
        $('#modalidade').html(data[0].modalidade);
        $('#dataInicio').html(data[0].dataInicio);
        $('#horaInicio').html(data[0].horaInicio);
        $('#duracao').html(data[0].duracao);
        $('#temperatura').html(data[0].temperatura);
        $('#agrotoxico').html(data[0].agrotoxico);
        $('#ingredienteAtivo').html(data[0].ingredienteAtivo);
        $('#dose').html(data[0].dose);
        $('#produtoComercial').html(data[0].prodComercial);
        $('#radiacao').html(data[0].radiacao);
        
        var id_pop_for = data[0].id_fornecedor;
        var id_pop_eng_1 = data[0].id_engenheiro_1;
        var id_pop_eng_2 = data[0].id_engenheiro_2;
        //FORNECEDOR 
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscaempresa/'+id_pop_for,
            dataType: 'json',
        }).done(function(data) {
            $('#nomeFornecedor').html(data[0].empresa);
            $('#cnpjFornecedor').html(data[0].cnpj);
        });
        //ENGENHEIRO 1
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscaengenheiro/'+id_pop_eng_1,
            dataType: 'json',
        }).done(function(data) {
            $('#engenheiro_1').html(data[0].nome);
            $('#crea_1').html(data[0].crea);
        });
        //ENGENHEIRO 2
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscaengenheiro/'+id_pop_eng_2,
            dataType: 'json',
        }).done(function(data) {
            $('#engenheiro_2').html(data[0].nome);
            $('#crea_2').html(data[0].crea);
        });
    });
	
});

function imprimir(){
    $("#imprimir").css("display", "none");
    $("body").css("margin-left", 0);
    $("body").css("margin-right", 0);
	window.print();
    window.location='../comunicado'
}