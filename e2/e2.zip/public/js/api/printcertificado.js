$( document ).ready(function(){
    //POPULA IMPRESSÃO
    var url_atual = window.location.origin;
    let url = window.location.pathname;
    let parts = url.split('/');
    let id = parts.pop() || parts.pop();
    
    $.ajax({
        type: "GET",
        url: url_atual +'/api/printcertificado/'+id,
        dataType: 'json',
        
    }).done(function(data) {
        var dados = data;
        var emissao = new Date(dados[0].dataEmissao);
        var di = new Date(dados[0].dataExpurgo);
        var df = new Date(dados[0].dataTerminoExpurgo);
        console.log(dados);

        $('#ciclo').html(dados[0].ciclo);
        if (dados[0].numeroFilho){ 
            $('#numeroCertificado').html(dados[0].numeroCertificado+'/'+dados[0].numeroFilho);
        }else{
            $('#numeroCertificado').html(dados[0].numeroCertificado);
        }
        $('#numeroComunicado').html(dados[0].numeroComunicado);
        $('#lote').html(dados[0].lote);
        $('#origem').html(dados[0].origem);
        $('#destino').html(dados[0].destino); 
        $('#pesoBruto').html(dados[0].pesoBruto + ' ' + dados[0].id_unidade_medida);
        $('#destino').html(dados[0].destino);
        $('#marcas').html(dados[0].marca);
        $('#qtdVolume').html(dados[0].qtd+' - '+dados[0].natProduto);
        $('#numeroDosCtrs').html(dados[0].numeroDosCtrs);
        $('#natProduto').html(dados[0].qtd+' - '+dados[0].natProduto);
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscamunicipio/'+dados[0].id_municipio,
            dataType: 'json',
        }).done(function(data) {
            $('#remetente').html(dados[0].empresa + ' - ' + dados[0].endereco + ', '+dados[0].numero+' - '+dados[0].bairro+' - '+ data[0].nomeMunicipio+'-'+data[0].ufMunicipio+' - '+data[0].pais);
        });
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscadestinatario/'+dados[0].destinatario,
            dataType: 'json',
        }).done(function(data) {
            $('#destinatario').html(data[0].empresa + ' - ' + data[0].endereco + ', '+data[0].numero+' - '+data[0].bairro+' - '+ data[0].nomeMunicipio+'-'+data[0].ufMunicipio+' - '+data[0].pais+ ' CONTATO: '+data[0].contato+ ' / '+ data[0].email+ ' TEL.:'+ data[0].telefone1 + ' CNPJ: '+ data[0].cnpj);
        });
        $('#navio').html(dados[0].navio);
        $('#modalidade').html(dados[0].produtoUtilizado);
        $('#tempTratamento').html(dados[0].tempTratamento);
        $('#dataExpurgo').html(di.toLocaleDateString('pt-BR'));
        $('#dataTerminoExpurgo').html(df.toLocaleDateString('pt-BR'));
        $('#horaInicio').html(dados[0].horaInicio);
        $('#horaFim').html(dados[0].horaFim);
        $('#tempoExposicao').html(dados[0].tempoExposicao);
        $('#temperatura').html(dados[0].temperatura);
        $('#dataEmissao').html(emissao.toLocaleDateString('pt-BR'));
        
        
        var id_eng = dados[0].id_engenheiro;
        //ENGENHEIRO 
        $.ajax({
            type: "GET",
            url: url_atual +'/api/buscaengenheiro/'+id_eng,
            dataType: 'json',
        }).done(function(data) {
            $('#engenheiro').html(data[0].nome);
            $('#formacao').html(data[0].formacao);
            $('#crea').html('CREA: '+data[0].crea);
        });
        
    });
	
});

function imprimir(){
    $("#imprimir").css("display", "none");
    $("body").css("margin-left", 0);
    $("body").css("margin-right", 0);
	window.print();
    window.location='../certificado'
}