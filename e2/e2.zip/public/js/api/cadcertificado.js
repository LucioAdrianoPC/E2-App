function carrega(){
    var url_atual = window.location.origin;
    var url_string = window.location.href;
    var url1 = new URL(url_string);
    var idce = url1.searchParams.get("idce");
    var filho = url1.searchParams.get("filho");
    var idMae = url1.searchParams.get("idmae");
    var idRem = 0;
    var op = '';
    let url = window.location.pathname;
    let parts = url.split('/');
    let id = parts.pop() || parts.pop();

    if(filho == 'true'){
        $('#numeroFilho').css('display', 'block');
        $('#numeroCertificado').css('display', 'none');
        $('#cert').html(id);
        $.ajax({
            type: "GET",
            url: url_atual +'/api/geranumerofilho/'+id,
            dataType: 'json',
        }).done(function(data) {
            $('#numeroFilho').val(data[0].numeroFilho + 1);
        });
        $('#id_mae').val(idMae);
    }else{
        $('#numeroFilho').css('display', 'none');
        $('#numeroCertificado').css('display', 'block');
        $('#numeroFilho').val(0);
        $('#id_mae').val(0);
    }
    if(idce){
        op = 'editar';
        $("#idCertificado").val(idce);
    }else{
        op = 'novo';
        $("#idCertificado").val(0);
    }
    var popula_unidade = '';
    var popula_destinatario = '<option value="0">SELECIONE UMA EMPRESA</option>';
    var popula_remetente = '<option value="0">SELECIONE UMA EMPRESA</option>';
    var popula_empresa = '';
    var idEstufa = 0;
    if (op === 'novo'){
        setTimeout(() => {
            $.ajax({
                type: "GET",
                url: url_atual +'/api/geracertificado/'+id,
                dataType: 'json',
                
            }).done(function(data) {
                $('#idEngenheiro').val(data[0].id_engenheiro_2);
                $('#idComunicado').val(data[0].idComunicado);
                $('#numeroCertificado').val(data[0].numeroComunicado);
                $('#numeroComunicado').val(data[0].numeroComunicado);
                $('#origem').val(data[0].nomeMunicipio + ' - ' + data[0].ufMunicipio );
                $('#marcas').val(data[0].marcas);
                $('#qtdVolume').val(data[0].quantidade);
                $('#numDescVolumes').val(data[0].numDescVolumes);
                $('#natProduto').val(data[0].numDescVolumes);
                if (data[0].modalidade == 'AR QUENTE FORÇADO'){
                    $('#modalidade').val(data[0].modalidade + ' / HIGH TEMPERATURE (HT)');
                }else{
                    $('#modalidade').val(data[0].modalidade);
                }
                $('#dataExpurgo').val(data[0].dataInicio);
                $('#dataTerminoExpurgo').val(data[0].dataInicio);
                $('#tempTratamento').val(data[0].temperatura);
                $('#horaInicio').val(data[0].horaInicio);
                var hfim = data[0].horaInicio;
                var hf = hfim.substr(0, 2);
                var mf = hfim.substr(3, 2);
                var dura = data[0].duracao.replace(/[^0-9]/g, '');
                var res = parseInt(mf) + parseInt(dura);
                var hora = parseInt(hf);
                var minutos = 0;
                if (res > 59){
                    while(res > 59){
                        res = res - 60;
                        hora = hora + 1;
                        if (res > 59){
                            hora = hora + 1;
                            res = res - 60;
                        }
                    }
                }
                if(res <= 9){
                    minutos = '0' + res;
                }else{
                    minutos = res;
                }
                $('#horaFim').val(hora + ':' + minutos);
                $('#tempo').val(data[0].duracao);
                idRem = data[0].id_fornecedor;
                $.ajax({
                    type: 'GET',
                    url: url_atual + '/api/selecionaestufa',
                    dataType: 'json'
                }).done(function(data){
                    var dadosEstufa = data;
                    var popula_estufa = '';
                    for(i=0;i<dadosEstufa.length ;i++){
                        if (data[0].id_estufa == dadosEstufa[i].id_estufa){
                            popula_estufa = popula_estufa + "<option value='"+dadosEstufa[i].idFornecedor+"' selected>" +dadosEstufa[i].fornecedor + "</option>";
                            $('#localFumigacao').val(dadosEstufa[i].nomeMunicipio+' - '+dadosEstufa[i].ufMunicipio);
                        }else{
                            popula_estufa = popula_estufa + "<option value='"+dadosEstufa[i].idFornecedor+"'>" +dadosEstufa[i].fornecedor + "</option>";
                            $('#localFumigacao').val(dadosEstufa[i].nomeMunicipio+' - '+dadosEstufa[i].ufMunicipio);
                        }
                            
                    }
                    $("#local").html(popula_estufa).show();
                    
                });
            });
        }, 200);

        $.ajax({
            type: "GET",
            url: url_atual +'/api/unidade',
            dataType: 'json',
        }).done(function(data) {
            for(i=0;i<data.length ;i++){
                popula_unidade = popula_unidade + "<option value='"+data[i].abreviacao+"'>" +data[i].abreviacao + "</option>";
            }
            $("#unidadeMedida").html(popula_unidade);
            $.ajax({
                type: "GET",
                url: url_atual +'/api/empresas',
                dataType: 'json',
            }).done(function(data) {
                var dados_empresa = data;
                for(i=0;i<dados_empresa.length ;i++){
                    if ($('#id_mae').val() == 0){
                        if (idRem == dados_empresa[i].idEmpresa){
                            popula_destinatario = popula_destinatario + "<option value='"+dados_empresa[i].idEmpresa+"'selected>" +dados_empresa[i].empresa + "</option>";
                            $('#destino').val(dados_empresa[i].nomeMunicipio+ ' - '+dados_empresa[i].ufMunicipio);
                        }else{
                            popula_destinatario = popula_destinatario + "<option value='"+dados_empresa[i].idEmpresa+"'>" +dados_empresa[i].empresa + "</option>";
                        }
                            
                        if (88 == dados_empresa[i].idEmpresa){
                            popula_remetente = popula_remetente + "<option value='"+dados_empresa[i].idEmpresa+"' selected>" +dados_empresa[i].empresa + "</option>"; 
                        }else{
                            popula_remetente = popula_remetente + "<option value='"+dados_empresa[i].idEmpresa+"'>" +dados_empresa[i].empresa + "</option>";
                        }
                    }else{
                        popula_destinatario = popula_destinatario + "<option value='"+dados_empresa[i].idEmpresa+"'>" +dados_empresa[i].empresa + "</option>";
                        if (idRem == dados_empresa[i].idEmpresa){
                            popula_remetente = popula_remetente + "<option value='"+dados_empresa[i].idEmpresa+"' selected>" +dados_empresa[i].empresa + "</option>"; 
                        }else{
                            popula_remetente = popula_remetente + "<option value='"+dados_empresa[i].idEmpresa+"'>" +dados_empresa[i].empresa + "</option>";
                        }
                    }
                    
                }
                $("#destinatario").html(popula_destinatario);
                $("#remetente").html(popula_remetente);
            });
        });
    }else{
        setTimeout(() => {
            $.ajax({
                type: "GET",
                url: url_atual +'/api/popcertificado/'+idce,
                dataType: 'json',
                
            }).done(function(data) {
                var dataEmissao = new Date(data[0].dataEmissao); 
                var dataInicio = new Date(data[0].dataExpurgo);
                idEstufa = data[0].id_estufa;
                if ($('#id_mae').val() == 0){
                    $('#numeroCertificado').val(data[0].numeroCertificado);
                }else{
                    $('#cert').html(data[0].numeroCertificado + '/');
                }
                $('#numeroComunicado').val(data[0].numeroComunicado);
                $('#lote').val(data[0].lote);
                $('#ciclo').val(data[0].ciclo);
                $('#dataEmissao').val(dataEmissao. getFullYear() + '-' + (dataEmissao.getMonth()+1).toString().padStart(2, '0') + '-' +dataEmissao.getDate().toString().padStart(2, '0'));
                $('#unidadeMedida').html("<option value='"+data[0].id_unidade_medida+"' selected>" + data[0].id_unidade_medida + "</option>");
                $('#pesoBruto').val(data[0].pesoBruto);
                $('#origem').val(data[0].origem);
                $('#destino').val(data[0].destino);
                $('#marcas').val(data[0].marca);
                $('#qtdVolume').val(data[0].qtd);
                $('#numeroDosCtrs').val(data[0].numeroDosCtrs);
                $('#natProduto').val(data[0].natProduto);
                $('#remetente').html("<option value='"+data[0].idEmpresa+"' selected>" + data[0].empresa + "</option>");
                $('#navio').val(data[0].navio);
                $('#local').val();
                $('#localFumigacao').val('CARMO DE MINAS - MG');
                $('#modalidade').val(data[0].produtoUtilizado);
                $('#dataExpurgo').val(dataInicio. getFullYear() + '-' + (dataInicio.getMonth()+1).toString().padStart(2, '0') + '-' +dataInicio.getDate().toString().padStart(2, '0'));
                $('#dataTerminoExpurgo').val(dataInicio. getFullYear() + '-' + (dataInicio.getMonth()+1).toString().padStart(2, '0') + '-' +dataInicio.getDate().toString().padStart(2, '0'));
                $('#tempTratamento').val(data[0].tempTratamento);
                $('#horaInicio').val(data[0].horaInicio);
                $('#horaFim').val(data[0].horaFim);
                $('#temperatura').val(data[0].temperatura);
                $('#tempo').val(data[0].tempoExposicao);
                $('#observacao').val(data[0].observacao);
                $('#idEngenheiro').val(data[0].id_engenheiro);
                
                var idDest = data[0].destinatario;
                $.ajax({
                    type: "GET",
                    url: url_atual +'/api/popdestinatario/'+ idDest,
                    dataType: 'json',
                }).done(function(data) {
                    var dest = data;
                    $('#destinatario').html("<option value='"+dest[0].idEmpresa+"' selected>" + dest[0].empresa + "</option>");
                    $.ajax({
                        type: "GET",
                        url: url_atual +'/api/empresas',
                        dataType: 'json',
                    }).done(function(data) {
                        for(i=0;i<data.length ;i++){
                            popula_empresa = popula_empresa + "<option value='"+data[i].idEmpresa+"'>" +data[i].empresa + "</option>";
                        }
                        $("#destinatario").append(popula_empresa);
                        $("#remetente").append(popula_empresa);
                    });
                });

                $.ajax({
                    type: "GET",
                    url: url_atual +'/api/unidade',
                    dataType: 'json',
                }).done(function(data) {
                    var dadosUN = data;
                    for(i=0;i<dadosUN.length ;i++){
                        popula_unidade = popula_unidade + "<option value='"+dadosUN[i].abreviacao+"'>" +dadosUN[i].abreviacao + "</option>";
                    }
                    $("#unidadeMedida").append(popula_unidade);
                    
                });

                $.ajax({
                    type: 'GET',
                    url: url_atual + '/api/selecionaestufa',
                    dataType: 'json'
                }).done(function(data){
                    var dadosEstufa = data;
                    var popula_estufa = '';
                    for(i=0;i<dadosEstufa.length ;i++){
                        if (idEstufa == dadosEstufa[i].idFornecedor){
                            popula_estufa = popula_estufa + "<option value='"+dadosEstufa[i].idFornecedor+"' selected>" +dadosEstufa[i].fornecedor + "</option>";
                            $('#localFumigacao').val(dadosEstufa[i].nomeMunicipio+' - '+dadosEstufa[i].ufMunicipio);
                        }else{
                            popula_estufa = popula_estufa + "<option value='"+dadosEstufa[i].idFornecedor+"'>" +dadosEstufa[i].fornecedor + "</option>";
                        }
                            
                    }
                    $("#local").html(popula_estufa).show();
                    
                });

            });
        }, 200);
        
    }
}

function popDestino(){
    var url_atual = window.location.origin;
    var id = $('#destinatario').val();
    $.ajax({
        type: "GET",
        url: url_atual +'/api/destino/'+id,
        dataType: 'json',
    }).done(function(data) {
        $("#nomeDestinatario").val(data[0].empresa);
        $("#destino").val(data[0].nomeMunicipio + ' - ' + data[0].ufMunicipio);
    });
}

function popOrigem(){
    var url_atual = window.location.origin;
    var id = $('#remetente').val();
    $.ajax({
        type: "GET",
        url: url_atual +'/api/destino/'+id,
        dataType: 'json',
    }).done(function(data) {
        $("#nomeRemetente").val(data[0].empresa);
        $("#origem").val(data[0].nomeMunicipio + ' - ' + data[0].ufMunicipio);
    });
}

function popEstufa(){
    var url_atual = window.location.origin;
    var id = $('#local').val();
    $.ajax({
        type: "GET",
        url: url_atual +'/api/popfornecedor/'+id,
        dataType: 'json',
    }).done(function(data) {
        $("#localFumigacao").val(data[0].nomeMunicipio + ' - ' + data[0].ufMunicipio);
    });
}

function salvar(){
    var url_atual = window.location.origin;
    var id = $("#idCertificado").val();
    var param = "?numeroCertificado="+$('#numeroCertificado').val()+"&numeroFilho="+$('#numeroFilho').val()+"&numeroComunicado="+$('#numeroComunicado').val()+"&dataEmissao="+$('#dataEmissao').val()+"&pesoBruto="+$('#pesoBruto').val()+"&origem="+$('#origem').val()+"&destino="+$('#destino').val()+"&marca="+$('#marcas').val()+"&qtdVolume="+$('#qtdVolume').val()+"&numeroDosCtrs="+$('#numeroDosCtrs').val()+"&natProduto="+$('#natProduto').val()+"&qtd="+$('#qtdVolume').val()+"&destinatario="+$('#destinatario').val()+"&navio="+$('#navio').val()+"&produtoUtilizado="+$('#modalidade').val()+"&dataExpurgo="+$('#dataExpurgo').val()+"&dataTerminoExpurgo="+$('#dataTerminoExpurgo').val()+"&tempTratamento="+$('#tempTratamento').val()+"&tempoExposicao="+$('#tempo').val()+"&horaInicio="+$('#horaInicio').val()+"&horaFim="+$('#horaFim').val()+"&temperatura="+$('#temperatura').val()+"&observacoes="+$('#observacao').val()+"&frase=Only the wooden creates (Pallets) have been trated&flg_status=A&flg_type=M&flg_visivel=S&lote="+$('#lote').val()+"&ciclo="+$('#ciclo').val()+"&id_unidade_medida="+$('#unidadeMedida').val()+"&id_remetente="+$('#remetente').val()+"&id_estufa="+$('#local').val()+"&id_engenheiro="+$('#idEngenheiro').val()+"&id_mae="+$('#id_mae').val()+"&id_filhote=0";

    if (id == 0){
        $.ajax({
            type: "POST",
            url: url_atual +'/api/cadcertificado/'+param,
            timeout: 0,
        }).done(function(data) {
            if ($('#id_mae').val() == 0){
                var id_com = $('#idComunicado').val();
                $.ajax({
                    type: "PUT",
                    url: url_atual +'/api/cadcomunicado/'+id_com+'/?status=C',
                    timeout: 0,
                }).done(function(data) {
                    console.log(data);
                });
            }
            alert("Registro salvo com sucesso!");
            window.location='../certificado';
        });
    }else{
        $.ajax({
            type: "PUT",
            url: url_atual +'/api/cadcertificado/'+id+'/'+param,
            timeout: 0,
        }).done(function(data) {
            alert("Registro editado com sucesso!");
            window.location='../certificado'
        });
    }
}